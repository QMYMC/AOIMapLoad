using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

public class AOIManagher : MonoBehaviour
{
    public int mapWidth;
    public int mapHeight;
    public int viewRadius=5;
    
    public GameObject tilePrefab;
    private GameObject[,] mapGrid;

    public GameObject player;
    
    // Start is called before the first frame update
    void Start()
    {
        mapGrid = new GameObject[mapWidth, mapHeight];
        GenerateMap();
        
        if (player != null)
        {
            player.transform.position = new Vector3(mapWidth / 2, 0.5f, mapHeight / 2); // 将玩家物体放置在地图中心
        }
        LoadAOIAroundPlayer(player.transform.position);
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 playerPosition = player.transform.position;
        if (Input.GetKeyDown(KeyCode.W)) playerPosition.z += 1;
        if (Input.GetKeyDown(KeyCode.S)) playerPosition.z -= 1;
        if (Input.GetKeyDown(KeyCode.D)) playerPosition.x += 1;
        if (Input.GetKeyDown(KeyCode.A)) playerPosition.x -= 1;
        player.transform.position = playerPosition;
        
        LoadAOIAroundPlayer(playerPosition);
    }

    void GenerateMap()
    {
        for (int x = 0; x < mapWidth; x++)
        {
            for (int z = 0; z < mapHeight; z++)
            {
                GameObject tile=Instantiate(tilePrefab, new Vector3(x,0,z), Quaternion.identity);
                tile.name = "Tile" + x + "_" + z;
                Renderer tileRenderer = tile.GetComponent<Renderer>();
                tileRenderer.material.color=new Color(Random.value, Random.value, Random.value);
                mapGrid[x, z] = tile;
            }
        }
    }

    void LoadAOIAroundPlayer(Vector3 playerPosition)
    {
        for (int x = 0; x < mapWidth; x++)
        {
            for (int z = 0; z < mapHeight; z++)
            {
                float distance=Vector3.Distance(new Vector3(x,0,z),playerPosition);
                bool isInAOI = distance < viewRadius;
                
                mapGrid[x,z].SetActive(isInAOI);
            }
        }
    }
}
